"""Low-level helpers: unit conversion, address handling, and minimal ABI codec.

This module intentionally avoids heavy dependencies (no web3, no eth-abi).
Only the encodings needed for standard ERC-20 read calls and Transfer-event
log decoding are implemented, with the common function selectors hard-coded.
"""

from __future__ import annotations

WEI_PER_ETHER = 10**18

# keccak256("Transfer(address,address,uint256)")
TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"

# Pre-computed 4-byte function selectors for standard ERC-20 read methods.
SELECTORS = {
    "balanceOf(address)": "0x70a08231",
    "decimals()": "0x313ce567",
    "symbol()": "0x95d89b41",
    "name()": "0x06fdde03",
    "totalSupply()": "0x18160ddd",
}


def is_address(value: str) -> bool:
    """Return True if *value* looks like a 20-byte hex address."""
    if not isinstance(value, str):
        return False
    if not value.startswith("0x"):
        return False
    body = value[2:]
    if len(body) != 40:
        return False
    try:
        int(body, 16)
    except ValueError:
        return False
    return True


def normalize_address(value: str) -> str:
    """Lower-case and validate an address, raising on bad input."""
    if not is_address(value):
        raise ValueError(f"not a valid EVM address: {value!r}")
    return value.lower()


def to_checksum(value: str) -> str:
    """EIP-55 checksummed address.

    Uses a pure-Python keccak implementation so no external dependency is
    required. Falls back to the lower-cased address if hashing is unavailable.
    """
    addr = normalize_address(value)[2:]
    digest = _keccak256(addr.encode("ascii")).hex()
    out = ["0x"]
    for ch, h in zip(addr, digest):
        if ch in "0123456789":
            out.append(ch)
        else:
            out.append(ch.upper() if int(h, 16) >= 8 else ch)
    return "".join(out)


def wei_to_ether(wei: int) -> float:
    """Convert a wei integer to a float number of ether."""
    return wei / WEI_PER_ETHER


def from_units(raw: int, decimals: int) -> float:
    """Scale a raw token amount down by *decimals*."""
    return raw / (10**decimals)


def hex_to_int(value) -> int:
    """Parse a 0x-prefixed hex quantity (or pass through an int)."""
    if isinstance(value, int):
        return value
    if value is None:
        return 0
    return int(value, 16)


def encode_call(selector: str, address: str | None = None) -> str:
    """Encode calldata for a read call with at most one address argument."""
    data = selector
    if address is not None:
        data += normalize_address(address)[2:].rjust(64, "0")
    return data


def decode_uint(hex_data: str) -> int:
    """Decode a single 32-byte word as an unsigned integer."""
    if not hex_data or hex_data == "0x":
        return 0
    return int(hex_data, 16)


def decode_address(word: str) -> str:
    """Decode a 32-byte word (topic or return value) into an address."""
    clean = word[2:] if word.startswith("0x") else word
    return "0x" + clean[-40:]


def decode_string(hex_data: str) -> str:
    """Decode an ABI-encoded dynamic string, with a bytes32 fallback.

    Some older tokens (e.g. MKR) return a fixed bytes32 rather than a proper
    dynamic string, so we fall back to stripping trailing null bytes.
    """
    clean = hex_data[2:] if hex_data.startswith("0x") else hex_data
    if not clean:
        return ""
    raw = bytes.fromhex(clean)
    # Standard dynamic string: [offset(32)][length(32)][data...]
    if len(raw) >= 64:
        length = int.from_bytes(raw[32:64], "big")
        if 0 < length <= len(raw) - 64:
            try:
                return raw[64:64 + length].decode("utf-8").rstrip("\x00")
            except UnicodeDecodeError:
                pass
    # bytes32 fallback
    try:
        return raw.rstrip(b"\x00").decode("utf-8")
    except UnicodeDecodeError:
        return ""


# --- Minimal pure-Python Keccak-256 (used only for EIP-55 checksums) --------

def _keccak256(data: bytes) -> bytes:
    return _Keccak(data).digest()


class _Keccak:
    """Compact Keccak-256 implementation (sponge, rate 1088, capacity 512)."""

    _RC = [
        0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
        0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
        0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
        0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
        0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
        0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
        0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
        0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
    ]
    _ROT = [
        [0, 36, 3, 41, 18], [1, 44, 10, 45, 2], [62, 6, 43, 15, 61],
        [28, 55, 25, 21, 56], [27, 20, 39, 8, 14],
    ]

    def __init__(self, data: bytes):
        self._state = [[0] * 5 for _ in range(5)]
        self._absorb(data)

    @staticmethod
    def _rotl(x: int, n: int) -> int:
        return ((x << n) | (x >> (64 - n))) & 0xFFFFFFFFFFFFFFFF

    def _keccak_f(self) -> None:
        s = self._state
        for rnd in range(24):
            c = [s[x][0] ^ s[x][1] ^ s[x][2] ^ s[x][3] ^ s[x][4] for x in range(5)]
            d = [c[(x - 1) % 5] ^ self._rotl(c[(x + 1) % 5], 1) for x in range(5)]
            for x in range(5):
                for y in range(5):
                    s[x][y] ^= d[x]
            b = [[0] * 5 for _ in range(5)]
            for x in range(5):
                for y in range(5):
                    b[y][(2 * x + 3 * y) % 5] = self._rotl(s[x][y], self._ROT[x][y])
            for x in range(5):
                for y in range(5):
                    s[x][y] = b[x][y] ^ ((~b[(x + 1) % 5][y]) & b[(x + 2) % 5][y])
            s[0][0] ^= self._RC[rnd]

    def _absorb(self, data: bytes) -> None:
        rate = 136  # bytes (1088 bits)
        padded = bytearray(data)
        padded.append(0x01)
        while len(padded) % rate != 0:
            padded.append(0x00)
        padded[-1] ^= 0x80
        for off in range(0, len(padded), rate):
            block = padded[off:off + rate]
            for i in range(0, rate, 8):
                lane = int.from_bytes(block[i:i + 8], "little")
                x = (i // 8) % 5
                y = (i // 8) // 5
                self._state[x][y] ^= lane
            self._keccak_f()

    def digest(self) -> bytes:
        out = bytearray()
        for y in range(5):
            for x in range(5):
                out += self._state[x][y].to_bytes(8, "little")
                if len(out) >= 32:
                    return bytes(out[:32])
        return bytes(out[:32])
