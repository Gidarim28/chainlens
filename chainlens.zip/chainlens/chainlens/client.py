"""A small, dependency-light EVM JSON-RPC client built on ``requests``."""

from __future__ import annotations

from typing import Any

import requests

from . import utils


class RpcError(RuntimeError):
    """Raised when the node returns a JSON-RPC error object."""


class EvmClient:
    """Talk to any EVM-compatible JSON-RPC endpoint.

    Parameters
    ----------
    rpc_url:
        HTTP(S) URL of the node, e.g. ``https://eth.llamarpc.com``.
    timeout:
        Per-request timeout in seconds.
    """

    def __init__(self, rpc_url: str, timeout: float = 30.0):
        if not rpc_url.startswith(("http://", "https://")):
            raise ValueError("rpc_url must be an http(s) URL")
        self.rpc_url = rpc_url
        self.timeout = timeout
        self._session = requests.Session()
        self._id = 0

    # -- raw transport -----------------------------------------------------

    def rpc(self, method: str, params: list[Any] | None = None) -> Any:
        """Send one JSON-RPC call and return the ``result`` field."""
        self._id += 1
        payload = {
            "jsonrpc": "2.0",
            "id": self._id,
            "method": method,
            "params": params or [],
        }
        resp = self._session.post(self.rpc_url, json=payload, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()
        if "error" in data and data["error"]:
            raise RpcError(f"{method}: {data['error']}")
        return data.get("result")

    # -- chain / block -----------------------------------------------------

    def chain_id(self) -> int:
        return utils.hex_to_int(self.rpc("eth_chainId"))

    def block_number(self) -> int:
        return utils.hex_to_int(self.rpc("eth_blockNumber"))

    def gas_price(self) -> int:
        """Current gas price in wei."""
        return utils.hex_to_int(self.rpc("eth_gasPrice"))

    def get_block(self, block: int | str = "latest", full: bool = False) -> dict:
        """Fetch a block by number or tag (``latest``, ``pending`` ...)."""
        tag = block if isinstance(block, str) else hex(block)
        result = self.rpc("eth_getBlockByNumber", [tag, full])
        if result is None:
            raise RpcError(f"block not found: {block}")
        return result

    # -- accounts ----------------------------------------------------------

    def get_balance(self, address: str, block: int | str = "latest") -> int:
        """Native-token balance in wei."""
        tag = block if isinstance(block, str) else hex(block)
        addr = utils.normalize_address(address)
        return utils.hex_to_int(self.rpc("eth_getBalance", [addr, tag]))

    def get_tx_count(self, address: str, block: int | str = "latest") -> int:
        tag = block if isinstance(block, str) else hex(block)
        addr = utils.normalize_address(address)
        return utils.hex_to_int(self.rpc("eth_getTransactionCount", [addr, tag]))

    # -- contract reads ----------------------------------------------------

    def call(self, to: str, data: str, block: int | str = "latest") -> str:
        """Perform an ``eth_call`` and return the raw hex result."""
        tag = block if isinstance(block, str) else hex(block)
        if not data.startswith("0x"):
            data = "0x" + data
        return self.rpc("eth_call", [{"to": utils.normalize_address(to), "data": data}, tag])

    # -- logs --------------------------------------------------------------

    def get_logs(
        self,
        address: str | None = None,
        from_block: int | str = "latest",
        to_block: int | str = "latest",
        topics: list | None = None,
    ) -> list[dict]:
        """Fetch event logs via ``eth_getLogs``."""
        flt: dict[str, Any] = {
            "fromBlock": from_block if isinstance(from_block, str) else hex(from_block),
            "toBlock": to_block if isinstance(to_block, str) else hex(to_block),
        }
        if address is not None:
            flt["address"] = utils.normalize_address(address)
        if topics is not None:
            flt["topics"] = topics
        return self.rpc("eth_getLogs", [flt]) or []

    def close(self) -> None:
        self._session.close()

    def __enter__(self) -> "EvmClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
