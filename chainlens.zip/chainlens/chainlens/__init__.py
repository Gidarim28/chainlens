"""chainlens — a lightweight on-chain data analysis toolkit for EVM chains.

Quick start
-----------
>>> from chainlens import EvmClient, ERC20            # doctest: +SKIP
>>> client = EvmClient("https://eth.llamarpc.com")    # doctest: +SKIP
>>> client.block_number()                             # doctest: +SKIP
"""

from .client import EvmClient, RpcError
from .tokens import ERC20, TokenInfo
from . import analysis, utils

__all__ = [
    "EvmClient",
    "RpcError",
    "ERC20",
    "TokenInfo",
    "analysis",
    "utils",
]

__version__ = "0.1.0"
