"""ERC-20 read helpers built on top of :class:`chainlens.client.EvmClient`."""

from __future__ import annotations

from dataclasses import dataclass

from .client import EvmClient
from . import utils


@dataclass
class TokenInfo:
    address: str
    symbol: str
    decimals: int
    name: str = ""

    def to_units(self, raw: int) -> float:
        """Scale a raw on-chain amount into human-readable units."""
        return utils.from_units(raw, self.decimals)


class ERC20:
    """Thin wrapper around the standard ERC-20 read methods.

    Example
    -------
    >>> token = ERC20(client, "0xA0b8...c2")   # doctest: +SKIP
    >>> token.symbol()                          # doctest: +SKIP
    'USDC'
    """

    def __init__(self, client: EvmClient, address: str):
        self.client = client
        self.address = utils.normalize_address(address)
        self._info: TokenInfo | None = None

    def symbol(self) -> str:
        raw = self.client.call(self.address, utils.SELECTORS["symbol()"])
        return utils.decode_string(raw)

    def name(self) -> str:
        raw = self.client.call(self.address, utils.SELECTORS["name()"])
        return utils.decode_string(raw)

    def decimals(self) -> int:
        raw = self.client.call(self.address, utils.SELECTORS["decimals()"])
        return utils.decode_uint(raw)

    def total_supply(self) -> int:
        raw = self.client.call(self.address, utils.SELECTORS["totalSupply()"])
        return utils.decode_uint(raw)

    def balance_of(self, holder: str) -> int:
        """Raw (un-scaled) balance of *holder*."""
        data = utils.encode_call(utils.SELECTORS["balanceOf(address)"], holder)
        raw = self.client.call(self.address, data)
        return utils.decode_uint(raw)

    def balance_of_units(self, holder: str) -> float:
        """Balance of *holder* scaled by the token's decimals."""
        return self.info().to_units(self.balance_of(holder))

    def info(self) -> TokenInfo:
        """Fetch and cache symbol/decimals/name for this token."""
        if self._info is None:
            self._info = TokenInfo(
                address=self.address,
                symbol=self.symbol(),
                decimals=self.decimals(),
                name=self.name(),
            )
        return self._info
