"""Turn raw on-chain data into tidy :class:`pandas.DataFrame` objects.

Every function here is pure: it takes already-fetched data (logs, blocks)
and returns a DataFrame or summary. This keeps the analysis layer fully
testable without a network connection.
"""

from __future__ import annotations

import pandas as pd

from . import utils


def transfers_to_dataframe(logs: list[dict], decimals: int = 18) -> pd.DataFrame:
    """Decode ERC-20 ``Transfer`` logs into a DataFrame.

    Columns: ``block``, ``tx_hash``, ``log_index``, ``token``, ``from``,
    ``to``, ``raw_value``, ``value``.
    """
    rows = []
    for log in logs:
        topics = log.get("topics", [])
        if not topics or topics[0].lower() != utils.TRANSFER_TOPIC:
            continue
        # Indexed transfers have from/to in topics[1:3]; value in data.
        if len(topics) < 3:
            continue
        rows.append(
            {
                "block": utils.hex_to_int(log.get("blockNumber")),
                "tx_hash": log.get("transactionHash"),
                "log_index": utils.hex_to_int(log.get("logIndex")),
                "token": (log.get("address") or "").lower(),
                "from": utils.decode_address(topics[1]),
                "to": utils.decode_address(topics[2]),
                "raw_value": utils.decode_uint(log.get("data", "0x")),
            }
        )
    df = pd.DataFrame(
        rows,
        columns=["block", "tx_hash", "log_index", "token", "from", "to", "raw_value"],
    )
    if not df.empty:
        df["value"] = df["raw_value"] / (10**decimals)
    else:
        df["value"] = pd.Series(dtype="float64")
    return df


def net_flows(transfers: pd.DataFrame) -> pd.DataFrame:
    """Net token flow per address (inflow - outflow).

    Returns a DataFrame indexed by address with ``inflow``, ``outflow`` and
    ``net`` columns, sorted by net flow descending.
    """
    if transfers.empty:
        return pd.DataFrame(columns=["inflow", "outflow", "net"])
    inflow = transfers.groupby("to")["value"].sum()
    outflow = transfers.groupby("from")["value"].sum()
    out = pd.DataFrame({"inflow": inflow, "outflow": outflow}).fillna(0.0)
    out["net"] = out["inflow"] - out["outflow"]
    return out.sort_values("net", ascending=False)


def top_holders_by_volume(transfers: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    """Addresses ranked by total transfer volume (sent + received)."""
    flows = net_flows(transfers)
    if flows.empty:
        return flows
    flows = flows.assign(volume=flows["inflow"] + flows["outflow"])
    return flows.sort_values("volume", ascending=False).head(n)


def block_gas_stats(block: dict) -> dict:
    """Summarise gas usage for a *full* block (fetched with ``full=True``).

    Returns gas used, gas limit, utilisation, tx count and base fee (gwei).
    """
    gas_used = utils.hex_to_int(block.get("gasUsed"))
    gas_limit = utils.hex_to_int(block.get("gasLimit"))
    base_fee = utils.hex_to_int(block.get("baseFeePerGas"))
    txs = block.get("transactions", [])
    return {
        "number": utils.hex_to_int(block.get("number")),
        "tx_count": len(txs),
        "gas_used": gas_used,
        "gas_limit": gas_limit,
        "utilization": (gas_used / gas_limit) if gas_limit else 0.0,
        "base_fee_gwei": base_fee / 1e9,
    }


def transactions_to_dataframe(block: dict) -> pd.DataFrame:
    """Build a DataFrame of transactions from a full block.

    Columns: ``tx_hash``, ``from``, ``to``, ``value_eth``,
    ``gas_price_gwei``, ``nonce``.
    """
    txs = block.get("transactions", [])
    rows = []
    for tx in txs:
        if not isinstance(tx, dict):
            continue  # block was fetched without full=True
        rows.append(
            {
                "tx_hash": tx.get("hash"),
                "from": (tx.get("from") or "").lower(),
                "to": (tx.get("to") or "").lower() or None,
                "value_eth": utils.wei_to_ether(utils.hex_to_int(tx.get("value"))),
                "gas_price_gwei": utils.hex_to_int(tx.get("gasPrice")) / 1e9,
                "nonce": utils.hex_to_int(tx.get("nonce")),
            }
        )
    return pd.DataFrame(
        rows,
        columns=["tx_hash", "from", "to", "value_eth", "gas_price_gwei", "nonce"],
    )


def summarize(transfers: pd.DataFrame) -> dict:
    """High-level summary of a transfer DataFrame for quick reporting."""
    if transfers.empty:
        return {"transfers": 0, "unique_addresses": 0, "total_value": 0.0}
    senders = set(transfers["from"])
    receivers = set(transfers["to"])
    return {
        "transfers": int(len(transfers)),
        "unique_addresses": len(senders | receivers),
        "unique_senders": len(senders),
        "unique_receivers": len(receivers),
        "total_value": float(transfers["value"].sum()),
        "blocks_spanned": int(transfers["block"].max() - transfers["block"].min() + 1),
    }
