"""Command-line interface for chainlens.

Examples
--------
    chainlens block latest --rpc https://eth.llamarpc.com
    chainlens balance 0xd8dA...6045 --rpc https://eth.llamarpc.com
    chainlens token 0xA0b8...c2 --holder 0xd8dA...6045 --rpc <url>
    chainlens transfers 0xA0b8...c2 --blocks 5 --rpc <url>
"""

from __future__ import annotations

import argparse
import json
import sys

import requests

from . import __version__, analysis
from .client import EvmClient, RpcError
from .tokens import ERC20
from . import utils

DEFAULT_RPC = "https://eth.llamarpc.com"


def _client(args) -> EvmClient:
    return EvmClient(args.rpc)


def cmd_block(args) -> int:
    with _client(args) as c:
        block = c.get_block(_parse_block(args.block), full=True)
        stats = analysis.block_gas_stats(block)
        print(json.dumps(stats, indent=2))
    return 0


def cmd_balance(args) -> int:
    with _client(args) as c:
        wei = c.get_balance(args.address)
        print(f"{utils.wei_to_ether(wei):.6f} (native)  [{wei} wei]")
    return 0


def cmd_token(args) -> int:
    with _client(args) as c:
        token = ERC20(c, args.address)
        info = token.info()
        print(f"{info.name} ({info.symbol}), decimals={info.decimals}")
        if args.holder:
            bal = token.balance_of_units(args.holder)
            print(f"balance of {args.holder}: {bal:,.6f} {info.symbol}")
    return 0


def cmd_transfers(args) -> int:
    with _client(args) as c:
        latest = c.block_number()
        from_block = max(0, latest - args.blocks + 1)
        token = ERC20(c, args.address)
        decimals = token.decimals()
        logs = c.get_logs(
            address=args.address,
            from_block=from_block,
            to_block=latest,
            topics=[utils.TRANSFER_TOPIC],
        )
        df = analysis.transfers_to_dataframe(logs, decimals=decimals)
        summary = analysis.summarize(df)
        print(json.dumps(summary, indent=2))
        if not df.empty:
            print("\nTop addresses by volume:")
            print(analysis.top_holders_by_volume(df, n=args.top).to_string())
    return 0


def cmd_gas(args) -> int:
    with _client(args) as c:
        price_gwei = c.gas_price() / 1e9
        block = c.get_block("latest", full=False)
        stats = analysis.block_gas_stats(block)
        print(f"gas price: {price_gwei:.3f} gwei")
        print(f"latest block #{stats['number']}: "
              f"{stats['utilization']*100:.1f}% full, "
              f"base fee {stats['base_fee_gwei']:.3f} gwei")
    return 0


def _parse_block(value: str):
    if value in ("latest", "pending", "earliest", "safe", "finalized"):
        return value
    return int(value)


def build_parser() -> argparse.ArgumentParser:
    # Shared options usable before *or* after the subcommand.
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "--rpc", default=DEFAULT_RPC, help=f"JSON-RPC URL (default: {DEFAULT_RPC})"
    )

    p = argparse.ArgumentParser(
        prog="chainlens",
        description=__doc__.split("\n")[0],
        parents=[common],
    )
    p.add_argument("--version", action="version", version=f"chainlens {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    b = sub.add_parser("block", parents=[common], help="show gas stats for a block")
    b.add_argument("block", nargs="?", default="latest")
    b.set_defaults(func=cmd_block)

    bal = sub.add_parser("balance", parents=[common], help="native balance of an address")
    bal.add_argument("address")
    bal.set_defaults(func=cmd_balance)

    tok = sub.add_parser("token", parents=[common], help="ERC-20 metadata and balance")
    tok.add_argument("address")
    tok.add_argument("--holder", help="address to check balance for")
    tok.set_defaults(func=cmd_token)

    tr = sub.add_parser(
        "transfers", parents=[common], help="analyze recent Transfer events for a token"
    )
    tr.add_argument("address")
    tr.add_argument("--blocks", type=int, default=5, help="how many recent blocks to scan")
    tr.add_argument("--top", type=int, default=10, help="rows in the volume ranking")
    tr.set_defaults(func=cmd_transfers)

    g = sub.add_parser("gas", parents=[common], help="current gas price and block utilisation")
    g.set_defaults(func=cmd_gas)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except (RpcError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except requests.RequestException as exc:
        print(f"network error: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
