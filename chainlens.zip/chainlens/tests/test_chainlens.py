"""Offline tests — no network required."""

import pandas as pd
import pytest

from chainlens import utils, analysis


# --- utils ------------------------------------------------------------------

def test_address_validation():
    assert utils.is_address("0x" + "ab" * 20)
    assert not utils.is_address("0x123")
    assert not utils.is_address("nope")


def test_checksum_known_vector():
    addr = "0x5aaeb6053f3e94c9b9a09f33669435e7ef1beaed"
    assert utils.to_checksum(addr) == "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed"


def test_keccak_empty():
    assert (
        utils._keccak256(b"").hex()
        == "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"
    )


def test_unit_conversions():
    assert utils.wei_to_ether(10**18) == 1.0
    assert utils.from_units(1_500_000, 6) == 1.5


def test_decode_uint_and_address():
    assert utils.decode_uint("0x0a") == 10
    word = "0x" + "00" * 12 + "ab" * 20
    assert utils.decode_address(word) == "0x" + "ab" * 20


def test_encode_call_with_address():
    data = utils.encode_call(utils.SELECTORS["balanceOf(address)"], "0x" + "11" * 20)
    assert data.startswith("0x70a08231")
    assert data.endswith("11" * 20)
    assert len(data) == 10 + 64  # selector + 32-byte word


def test_decode_string_dynamic():
    # ABI-encoded "USDC": offset=32, length=4, data padded to 32 bytes
    encoded = (
        "0x"
        + "20".rjust(64, "0")
        + "04".rjust(64, "0")
        + b"USDC".hex().ljust(64, "0")
    )
    assert utils.decode_string(encoded) == "USDC"


# --- analysis ---------------------------------------------------------------

def _fake_transfer_log(frm, to, value, block, idx):
    return {
        "blockNumber": hex(block),
        "transactionHash": "0x" + "cd" * 32,
        "logIndex": hex(idx),
        "address": "0x" + "ee" * 20,
        "topics": [
            utils.TRANSFER_TOPIC,
            "0x" + "00" * 12 + frm,
            "0x" + "00" * 12 + to,
        ],
        "data": hex(value),
    }


def test_transfers_to_dataframe():
    logs = [
        _fake_transfer_log("aa" * 20, "bb" * 20, 10**18, 100, 0),
        _fake_transfer_log("bb" * 20, "cc" * 20, 5 * 10**17, 101, 1),
    ]
    df = analysis.transfers_to_dataframe(logs, decimals=18)
    assert len(df) == 2
    assert df.iloc[0]["value"] == 1.0
    assert df.iloc[1]["value"] == 0.5
    assert df.iloc[0]["from"] == "0x" + "aa" * 20


def test_transfers_empty():
    df = analysis.transfers_to_dataframe([], decimals=18)
    assert df.empty
    assert "value" in df.columns


def test_net_flows():
    logs = [
        _fake_transfer_log("aa" * 20, "bb" * 20, 3 * 10**18, 1, 0),
        _fake_transfer_log("bb" * 20, "cc" * 20, 1 * 10**18, 2, 1),
    ]
    df = analysis.transfers_to_dataframe(logs, decimals=18)
    flows = analysis.net_flows(df)
    bb = "0x" + "bb" * 20
    # bb received 3, sent 1 -> net +2
    assert flows.loc[bb, "net"] == pytest.approx(2.0)


def test_summarize():
    logs = [_fake_transfer_log("aa" * 20, "bb" * 20, 10**18, 50, 0)]
    df = analysis.transfers_to_dataframe(logs, decimals=18)
    s = analysis.summarize(df)
    assert s["transfers"] == 1
    assert s["unique_addresses"] == 2
    assert s["total_value"] == pytest.approx(1.0)


def test_block_gas_stats():
    block = {
        "number": hex(123),
        "gasUsed": hex(15_000_000),
        "gasLimit": hex(30_000_000),
        "baseFeePerGas": hex(2_000_000_000),
        "transactions": [{}, {}, {}],
    }
    stats = analysis.block_gas_stats(block)
    assert stats["number"] == 123
    assert stats["utilization"] == pytest.approx(0.5)
    assert stats["base_fee_gwei"] == pytest.approx(2.0)
    assert stats["tx_count"] == 3


def test_transactions_to_dataframe():
    block = {
        "transactions": [
            {
                "hash": "0x" + "11" * 32,
                "from": "0x" + "AA" * 20,
                "to": "0x" + "BB" * 20,
                "value": hex(10**18),
                "gasPrice": hex(3_000_000_000),
                "nonce": hex(7),
            }
        ]
    }
    df = analysis.transactions_to_dataframe(block)
    assert len(df) == 1
    assert df.iloc[0]["value_eth"] == pytest.approx(1.0)
    assert df.iloc[0]["gas_price_gwei"] == pytest.approx(3.0)
    assert df.iloc[0]["from"] == "0x" + "aa" * 20
