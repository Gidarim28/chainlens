"""Minimal end-to-end example.

Run with:
    python examples/basic_usage.py
(uses a public Ethereum RPC; pass your own via the RPC_URL env var)
"""

import os

from chainlens import EvmClient, ERC20, analysis
from chainlens.utils import TRANSFER_TOPIC

RPC_URL = os.environ.get("RPC_URL", "https://eth.llamarpc.com")
USDC = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
VITALIK = "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045"


def main() -> None:
    with EvmClient(RPC_URL) as client:
        print(f"chain id      : {client.chain_id()}")
        latest = client.block_number()
        print(f"latest block  : {latest}")

        bal = client.get_balance(VITALIK)
        print(f"native balance: {bal / 1e18:.4f}")

        usdc = ERC20(client, USDC)
        info = usdc.info()
        print(f"token         : {info.name} ({info.symbol}), decimals={info.decimals}")

        logs = client.get_logs(
            address=USDC,
            from_block=latest - 3,
            to_block=latest,
            topics=[TRANSFER_TOPIC],
        )
        df = analysis.transfers_to_dataframe(logs, decimals=info.decimals)
        print("\nsummary:", analysis.summarize(df))
        if not df.empty:
            print("\ntop addresses by volume:")
            print(analysis.top_holders_by_volume(df, n=5).to_string())


if __name__ == "__main__":
    main()
